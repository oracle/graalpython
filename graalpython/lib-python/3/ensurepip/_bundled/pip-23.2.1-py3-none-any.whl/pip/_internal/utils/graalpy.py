# ATTENTION: GraalPy uses existence of this module to verify that it is
# running a patched pip in pip_hook.py
import os
import re
import zipfile
from pathlib import Path
from urllib.parse import urlparse

from pip._internal.models.candidate import InstallationCandidate
from pip._internal.models.link import Link
from pip._vendor import tomli
from pip._vendor.packaging.specifiers import SpecifierSet
from pip._vendor.packaging.version import VERSION_PATTERN

PATCHES_BASE_DIRS = [os.path.join(__graalpython__.core_home, "patches")]
if hasattr(__graalpython__, "tdebug"):
    PATCHES_BASE_DIRS += os.environ.get('PIPLOADER_PATCHES_BASE_DIRS', "").split(",")

DISABLE_PATCHING = os.environ.get('PIP_GRAALPY_DISABLE_PATCHING', '').lower() in ('true', '1')
DISABLE_VERSION_SELECTION = os.environ.get('PIP_GRAALPY_DISABLE_VERSION_SELECTION', '').lower() in ('true', '1')


def normalize_name(name):
    return re.sub('[-_.]+', '-', name).lower()


class PatchRepository:
    def __init__(self, base_dirs):
        self._repository = {}
        for base_dir in base_dirs:
            for package_dir in Path(base_dir).iterdir():
                denormalized_name = package_dir.name
                normalized_name = normalize_name(denormalized_name)
                metadata = {}
                if (metadata_path := package_dir / 'metadata.toml').is_file():
                    with open(metadata_path, 'rb') as f:
                        metadata = tomli.load(f)
                    metadata.setdefault('rules', [])
                    for rule in metadata['rules']:
                        if 'patch' in rule:
                            rule['patch'] = package_dir / rule['patch']
                self._repository[normalized_name] = metadata

    def rule_applicable(self, rule):
        if not __graalpython__.use_system_toolchain and rule.get('ignore-rule-on-llvm'):
            return False
        return True

    def get_rules(self, name):
        if metadata := self._repository.get(normalize_name(name)):
            return [rule for rule in metadata['rules'] if self.rule_applicable(rule)]

    def get_add_sources(self, name):
        if metadata := self._repository.get(normalize_name(name)):
            return metadata.get('add-sources')

    def get_priority_for_version(self, name, version):
        if rules := self.get_rules(name):
            for rule in rules:
                if self.rule_matches_version(rule, version):
                    return rule.get('install-priority', 1)
        return 0

    @staticmethod
    def rule_matches_version(rule, version):
        return not rule.get('version') or SpecifierSet(rule['version']).contains(version)

    def get_suggested_version_specs(self, name):
        versions = set()
        if rules := self.get_rules(name):
            for rule in rules:
                if 'patch' in rule and rule.get('install-priority', 1) > 0 and (version := rule.get('version')):
                    versions.add(version)
        return versions

    def get_matching_rule(self, name, requested_version, dist_type):
        if metadata := self.get_rules(name):
            for rule in metadata:
                if rule.get('dist-type', dist_type) != dist_type:
                    continue
                if not self.rule_matches_version(rule, requested_version):
                    continue
                return rule


__PATCH_REPOSITORY = None


def get_patch_repository():
    global __PATCH_REPOSITORY
    if not __PATCH_REPOSITORY:
        __PATCH_REPOSITORY = PatchRepository(PATCHES_BASE_DIRS)
    return __PATCH_REPOSITORY


def apply_graalpy_patches(filename, location):
    """
    Applies any GraalPy patches to package extracted from 'filename' into 'location'.
    Note that 'location' must be the parent directory of the package directory itself.
    For example: /path/to/site-package and not /path/to/site-packages/mypackage.
    """
    if DISABLE_PATCHING:
        return

    # we expect filename to be something like "pytest-5.4.2-py3-none-any.whl"
    archive_name = os.path.basename(filename)
    name_ver_match = re.match(fr"^(?P<name>.*?)-(?P<version>{VERSION_PATTERN}).*?\.(?P<suffix>tar\.gz|tar|whl|zip)$",
                              archive_name, re.VERBOSE | re.I)
    if not name_ver_match:
        print(f"GraalPy warning: could not parse package name, version, or format from {archive_name!r}.\n"
              "Could not determine if any GraalPy specific patches need to be applied.")
        return

    name = name_ver_match.group('name')
    version = name_ver_match.group('version')
    suffix = name_ver_match.group('suffix')
    is_wheel = suffix == "whl"

    if is_wheel and is_wheel_marked(filename):
        # We already processed it when building from source
        return

    import autopatch_capi
    import subprocess

    autopatch_capi.auto_patch_tree(location)

    print(f"Looking for GraalPy patches for {name}")
    repository = get_patch_repository()

    if is_wheel:
        # patches intended for binary distribution:
        rule = repository.get_matching_rule(name, version, 'wheel')
    else:
        # patches intended for source distribution if applicable
        rule = repository.get_matching_rule(name, version, 'sdist')
        if not rule:
            rule = repository.get_matching_rule(name, version, 'wheel')
        if rule and (subdir := rule.get('subdir')):
            # we may need to change wd if we are actually patching a source distribution
            # with a patch intended for a binary distribution, because in the source
            # distribution the actual deployed sources may be in a subdirectory (typically "src")
            location = os.path.join(location, subdir)
    if rule:
        if patch := rule.get('patch'):
            print(f"Patching package {name} using {patch}")
            exe = '.exe' if os.name == 'nt' else ''
            try:
                subprocess.run([f"patch{exe}", "-f", "-d", location, "-p1", "-i", str(patch)], check=True)
            except FileNotFoundError:
                print(
                    "WARNING: GraalPy needs the 'patch' utility to apply compatibility patches. Please install it using your system's package manager.")
            except subprocess.CalledProcessError:
                print(f"Applying GraalPy patch failed for {name}. The package may still work.")
    elif version_specs := repository.get_suggested_version_specs(name):
        print("We have patches to make this package work on GraalVM for some version(s).")
        print("If installing or running fails, consider using one of the versions that we have patches for:")
        for version_spec in version_specs:
            print(f'{name} {version_spec}')


def apply_graalpy_sort_order(sort_key_func):
    if DISABLE_VERSION_SELECTION:
        return sort_key_func

    def wrapper(self, candidate):
        default_sort_key = sort_key_func(self, candidate)
        priority = get_patch_repository().get_priority_for_version(candidate.name, str(candidate.version))
        return priority, default_sort_key

    return wrapper


class AddedSourceLink(Link):
    def __init__(self, url: str, filename: str):
        super().__init__(url)
        self._filename = filename

    @property
    def filename(self) -> str:
        return self._filename


def get_graalpy_candidates(name):
    repository = get_patch_repository()
    candidates = []
    for add_source in repository.get_add_sources(name) or []:
        version = add_source['version']
        url = add_source['url']
        match = re.search(r'\.(tar\.(?:gz|bz2|xz)|zip|whl)$', urlparse(url).path)
        assert match, "Couldn't determine URL suffix"
        suffix = match.group(1)
        # We need to force the filename to match the usual convention, otherwise we won't find a patch
        link = AddedSourceLink(url, f'{name}-{version}.{suffix}')
        candidates.append(InstallationCandidate(name=name, version=version, link=link))
    return candidates


MARKER_NAME = 'GRAALPY_MARKER'


def mark_wheel(path):
    if DISABLE_PATCHING:
        return
    with zipfile.ZipFile(path, 'a') as z:
        dist_info = None
        for name in z.namelist():
            if m := re.match(r'([^/]+.dist-info)/', name):
                dist_info = m.group(1)
                break
        assert dist_info, "Cannot find .dist_info in built wheel"
        marker = f'{dist_info}/{MARKER_NAME}'
        with z.open(marker, 'w'):
            pass


def is_wheel_marked(path):
    with zipfile.ZipFile(path) as z:
        return any(re.match(rf'[^/]+.dist-info/{MARKER_NAME}$', f) for f in z.namelist())
