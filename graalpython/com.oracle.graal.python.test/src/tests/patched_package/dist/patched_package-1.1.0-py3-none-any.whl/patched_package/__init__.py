def test_fun():
    return 'Unpatched'
