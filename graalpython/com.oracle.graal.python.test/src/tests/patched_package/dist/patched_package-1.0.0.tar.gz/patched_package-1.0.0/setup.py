# Dummy package for testing pip patching mechanism
# The source and binary distributions located next to this file must be
# manually updated every time this package is updated. To do that, run:
#
# PKG_VERSION='1.0.0' python3 setup.py bdist_wheel
# PKG_VERSION='1.1.0' python3 setup.py bdist_wheel
# PKG_VERSION='1.0.0' python3 setup.py sdist
# PKG_VERSION='1.1.0' python3 setup.py sdist
#
from setuptools import setup, find_packages
import os
setup(
    name='patched_package',
    version=os.environ['PKG_VERSION'],
    author='GraalPy developers',
    author_email='graalvm-users@oss.oracle.com',
    package_dir={'': 'src'},
    packages=find_packages(where='src'),
)