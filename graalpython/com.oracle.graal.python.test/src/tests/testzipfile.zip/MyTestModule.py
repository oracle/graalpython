def get_name():
    return __name__
def get_file():
    return __file__

class pupil():
  def __init__(self, firstname, secondname):
    self.firstname = firstname
    self.secondname = secondname
    self.numberClass = None

  def setClass(self, which):
    self.numberClass = which

  def __repr__(self):
    return "Name: {} {}\nClass: {}".format( self.firstname, self.secondname, self.numberClass)

