
class A():
  def hello(self):
    return "Hello from module A"

