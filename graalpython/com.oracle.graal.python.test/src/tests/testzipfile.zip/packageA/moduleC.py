def get_file():
  return __file__

class C():
  def hello(sel):
    return "Hello from module C"
